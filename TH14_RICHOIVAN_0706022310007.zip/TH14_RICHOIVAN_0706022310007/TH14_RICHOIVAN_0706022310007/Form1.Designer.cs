﻿namespace TH14_RICHOIVAN_0706022310007
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_M = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.DTP_MD = new System.Windows.Forms.DateTimePicker();
            this.BT_I = new System.Windows.Forms.Button();
            this.BT_D = new System.Windows.Forms.Button();
            this.BT_A = new System.Windows.Forms.Button();
            this.comboBox_TE = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox_P = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox_T = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox_TA = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox_TH = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dgv_1 = new System.Windows.Forms.DataGridView();
            this.textBox_MI = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox_M
            // 
            this.textBox_M.Location = new System.Drawing.Point(839, 105);
            this.textBox_M.Name = "textBox_M";
            this.textBox_M.Size = new System.Drawing.Size(121, 22);
            this.textBox_M.TabIndex = 39;
            this.textBox_M.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_M_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(738, 107);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 22);
            this.label8.TabIndex = 38;
            this.label8.Text = "Minute :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(487, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 22);
            this.label7.TabIndex = 37;
            this.label7.Text = "Match Date :";
            // 
            // DTP_MD
            // 
            this.DTP_MD.Location = new System.Drawing.Point(620, 17);
            this.DTP_MD.Name = "DTP_MD";
            this.DTP_MD.Size = new System.Drawing.Size(340, 22);
            this.DTP_MD.TabIndex = 36;
            this.DTP_MD.ValueChanged += new System.EventHandler(this.DTP_MD_ValueChanged);
            // 
            // BT_I
            // 
            this.BT_I.Location = new System.Drawing.Point(820, 355);
            this.BT_I.Name = "BT_I";
            this.BT_I.Size = new System.Drawing.Size(140, 38);
            this.BT_I.TabIndex = 35;
            this.BT_I.Text = "Insert";
            this.BT_I.UseVisualStyleBackColor = true;
            this.BT_I.Click += new System.EventHandler(this.BT_I_Click);
            // 
            // BT_D
            // 
            this.BT_D.Location = new System.Drawing.Point(854, 317);
            this.BT_D.Name = "BT_D";
            this.BT_D.Size = new System.Drawing.Size(75, 32);
            this.BT_D.TabIndex = 34;
            this.BT_D.Text = "Delete";
            this.BT_D.UseVisualStyleBackColor = true;
            this.BT_D.Click += new System.EventHandler(this.BT_D_Click);
            // 
            // BT_A
            // 
            this.BT_A.Location = new System.Drawing.Point(854, 279);
            this.BT_A.Name = "BT_A";
            this.BT_A.Size = new System.Drawing.Size(74, 32);
            this.BT_A.TabIndex = 33;
            this.BT_A.Text = "Add";
            this.BT_A.UseVisualStyleBackColor = true;
            this.BT_A.Click += new System.EventHandler(this.BT_A_Click);
            // 
            // comboBox_TE
            // 
            this.comboBox_TE.FormattingEnabled = true;
            this.comboBox_TE.Items.AddRange(new object[] {
            "CR",
            "CY",
            "GO",
            "GR",
            "GW",
            "PM"});
            this.comboBox_TE.Location = new System.Drawing.Point(839, 240);
            this.comboBox_TE.Name = "comboBox_TE";
            this.comboBox_TE.Size = new System.Drawing.Size(121, 24);
            this.comboBox_TE.TabIndex = 32;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(748, 240);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 22);
            this.label6.TabIndex = 31;
            this.label6.Text = "Type :";
            // 
            // comboBox_P
            // 
            this.comboBox_P.FormattingEnabled = true;
            this.comboBox_P.Location = new System.Drawing.Point(839, 193);
            this.comboBox_P.Name = "comboBox_P";
            this.comboBox_P.Size = new System.Drawing.Size(121, 24);
            this.comboBox_P.TabIndex = 30;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(738, 193);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 22);
            this.label5.TabIndex = 29;
            this.label5.Text = "Player :";
            // 
            // comboBox_T
            // 
            this.comboBox_T.FormattingEnabled = true;
            this.comboBox_T.Location = new System.Drawing.Point(839, 148);
            this.comboBox_T.Name = "comboBox_T";
            this.comboBox_T.Size = new System.Drawing.Size(121, 24);
            this.comboBox_T.TabIndex = 28;
            this.comboBox_T.SelectedIndexChanged += new System.EventHandler(this.comboBox_T_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(748, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 22);
            this.label4.TabIndex = 27;
            this.label4.Text = "Team :";
            // 
            // comboBox_TA
            // 
            this.comboBox_TA.FormattingEnabled = true;
            this.comboBox_TA.Location = new System.Drawing.Point(620, 62);
            this.comboBox_TA.Name = "comboBox_TA";
            this.comboBox_TA.Size = new System.Drawing.Size(160, 24);
            this.comboBox_TA.TabIndex = 26;
            this.comboBox_TA.SelectedIndexChanged += new System.EventHandler(this.comboBox_TA_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(488, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 22);
            this.label3.TabIndex = 25;
            this.label3.Text = "Team Away :";
            // 
            // comboBox_TH
            // 
            this.comboBox_TH.FormattingEnabled = true;
            this.comboBox_TH.Location = new System.Drawing.Point(131, 66);
            this.comboBox_TH.Name = "comboBox_TH";
            this.comboBox_TH.Size = new System.Drawing.Size(134, 24);
            this.comboBox_TH.TabIndex = 24;
            this.comboBox_TH.SelectedIndexChanged += new System.EventHandler(this.comboBox_TH_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(2, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 22);
            this.label2.TabIndex = 23;
            this.label2.Text = "Team Home :";
            // 
            // dgv_1
            // 
            this.dgv_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_1.Location = new System.Drawing.Point(30, 133);
            this.dgv_1.Name = "dgv_1";
            this.dgv_1.RowHeadersWidth = 51;
            this.dgv_1.RowTemplate.Height = 24;
            this.dgv_1.Size = new System.Drawing.Size(690, 394);
            this.dgv_1.TabIndex = 22;
            // 
            // textBox_MI
            // 
            this.textBox_MI.Location = new System.Drawing.Point(130, 19);
            this.textBox_MI.Name = "textBox_MI";
            this.textBox_MI.Size = new System.Drawing.Size(135, 22);
            this.textBox_MI.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 22);
            this.label1.TabIndex = 20;
            this.label1.Text = "Match ID :";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1059, 544);
            this.Controls.Add(this.textBox_M);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.DTP_MD);
            this.Controls.Add(this.BT_I);
            this.Controls.Add(this.BT_D);
            this.Controls.Add(this.BT_A);
            this.Controls.Add(this.comboBox_TE);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.comboBox_P);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.comboBox_T);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox_TA);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox_TH);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgv_1);
            this.Controls.Add(this.textBox_MI);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_M;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker DTP_MD;
        private System.Windows.Forms.Button BT_I;
        private System.Windows.Forms.Button BT_D;
        private System.Windows.Forms.Button BT_A;
        private System.Windows.Forms.ComboBox comboBox_TE;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox_P;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox_T;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox_TA;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox_TH;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgv_1;
        private System.Windows.Forms.TextBox textBox_MI;
        private System.Windows.Forms.Label label1;
    }
}

