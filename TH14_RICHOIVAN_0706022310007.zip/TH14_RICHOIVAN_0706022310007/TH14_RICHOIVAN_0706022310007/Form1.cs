﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace TH14_RICHOIVAN_0706022310007
{
    public partial class Form1 : Form
    {
        MySqlConnection sqlconnect;
        MySqlCommand sqlcommand;
        MySqlDataAdapter sqldataadapter;

        DataTable dgv = new DataTable();
        DataTable dtmtch = new DataTable();
        DataTable dthome = new DataTable();
        DataTable dtaway = new DataTable();
        DataTable datatype = new DataTable();
        DataTable dtplayer = new DataTable();
        DataTable lastmatch = new DataTable();
        DataTable dt = new DataTable();
        DataTable matchid = new DataTable();
        string query = "";
        string year = "";
        string month = "";
        string date = "";
        int totalmatch = 0;
        int last = 0;
        int select = 0;
        int tlhome = 0;
        int tlaway = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            InitializeComponent();
            textBox_MI.Enabled = false;
            try
            {
                sqlconnect = new MySqlConnection("server = localhost; uid = root; pwd = MySQLISBUC2024Sean; database = premier_league");
                sqlconnect.Open();
                query = "SELECT * From Team";
                sqlcommand = new MySqlCommand(query, sqlconnect);
                sqldataadapter = new MySqlDataAdapter(sqlcommand);
                sqldataadapter.Fill(dthome);
                sqldataadapter.Fill(dthome); query = "select * from `dmatch`";
                sqlcommand = new MySqlCommand(query, sqlconnect);
                sqldataadapter = new MySqlDataAdapter(sqlcommand);
                sqldataadapter.Fill(datatype);
                sqlconnect.Close();
                comboBox_TH.DataSource = dthome;
                comboBox_TH.DisplayMember = "team_name";
                comboBox_TH.ValueMember = "team_id";
                comboBox_TH.Text = "";
                comboBox_TA.DataSource = dtaway;
                comboBox_TA.DisplayMember = "team_name";
                comboBox_TA.ValueMember = "team_id";
                comboBox_TA.Text = "";
                comboBox_T.DataSource = dthome;
                comboBox_T.DisplayMember = "team_name";
                comboBox_T.ValueMember = "team_id";
                dgv.Columns.Add("Team");
                dgv.Columns.Add("Player");
                dgv.Columns.Add("Type");
                dgv_1.DataSource = dgv;
                dtmtch.Columns.Add("Minute");
                dtmtch.Columns.Add("team_id");
                dtmtch.Columns.Add("player_id");
                dtmtch.Columns.Add("Type");
                comboBox_T.Text = "";
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BT_I_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox_MI.Text != "")
                {
                    for (int i = 0; i < dgv.Rows.Count; i++)
                    {
                        query = $"INSERT INTO DMatch VALUES ('{textBox_MI.Text}', '{dtmtch.Rows[i][0]}', '{dtmtch.Rows[i][1]}', '{dtmtch.Rows[i][2]}', '{dtmtch.Rows[i][3]}', '0');";
                        sqlconnect.Open();
                        sqlcommand = new MySqlCommand(query, sqlconnect);
                        sqlcommand.ExecuteNonQuery();
                        sqlconnect.Close();
                    }
                    query = $"INSERT INTO `match` VALUES ('{textBox_MI.Text}', '{year}-{month}-{date}', '{comboBox_TH.SelectedValue}', '{comboBox_TH.SelectedValue}', '{tlhome}', '{tlaway}', 'M002', '0');";
                    sqlconnect.Open();
                    sqlcommand = new MySqlCommand(query, sqlconnect);
                    sqlcommand.ExecuteNonQuery();
                    sqlconnect.Close();
                    comboBox_TA.Text = "";
                    comboBox_TH.Text = "";
                    textBox_M.Text = "";
                    comboBox_TE.Text = "";
                    comboBox_T.Text = "";
                    comboBox_P.Text = "";
                    textBox_MI.Text = "";
                    dgv.Rows.Clear();
                    dtmtch.Rows.Clear();
                    tlaway = 0;
                    tlhome = 0;
                }
                else
                {
                    MessageBox.Show("ERROR");
                }
            }

            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BT_A_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox_M.Text == "" || comboBox_T.Text == "" || comboBox_P.Text == "" || comboBox_TE.Text == "" || textBox_MI.Text == "")
                {
                    MessageBox.Show("ERROR");
                }
                else
                {
                    dgv.Rows.Add(comboBox_T.Text, comboBox_P.Text, comboBox_TE.Text);
                    if (comboBox_TE.Text == "GO" || comboBox_TE.Text == "GP")
                    {
                        if (comboBox_TA.Text == comboBox_T.Text)
                        {
                            tlaway++;
                        }
                        else
                        {
                            tlhome++;
                        }
                    }
                    if (comboBox_TE.Text == "GW")
                    {
                        if (comboBox_TA.Text == comboBox_T.Text)
                        {
                            tlhome++;
                        }
                        else
                        {
                            tlaway++;
                        }
                    }
                    dtmtch.Rows.Add(textBox_M.Text, comboBox_T.SelectedValue, comboBox_P.SelectedValue, comboBox_TE.Text);
                    textBox_MI.Clear();
                    textBox_M.Clear();
                    comboBox_TE.SelectedIndex = 0;
                    comboBox_T.SelectedIndex = 0;
                    comboBox_P.SelectedIndex = 0;
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BT_D_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgv_1.Rows.Count > 0)
                {
                    dgv_1.Rows.RemoveAt(dgv_1.SelectedRows[0].Index);
                    if (comboBox_TE.Text == "GO" || comboBox_TE.Text == "GP")
                    {
                        if (comboBox_TA.Text == comboBox_T.Text)
                        {
                            tlaway--;
                        }
                        else
                        {
                            tlhome--;
                        }
                    }
                    if (comboBox_TE.Text == "GW")
                    {
                        if (comboBox_TA.Text == comboBox_T.Text)
                        {
                            tlhome--;
                        }
                        else
                        {
                            tlaway--;
                        }
                    }
                }

            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox_TH_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (comboBox_TH.Text == comboBox_TA.Text)
                {
                    MessageBox.Show("Cannot Pick The same team");
                }
                else
                {
                    dt = new DataTable();
                    query = $"SELECT team_name, team_id FROM team WHERE team_id = '{comboBox_TH.SelectedValue}' or team_id = '{comboBox_TA.SelectedValue}'";
                    sqlcommand = new MySqlCommand(query, sqlconnect);
                    sqldataadapter = new MySqlDataAdapter(sqlcommand);
                    sqldataadapter.Fill(dt);

                    comboBox_T.ValueMember = "team_id";
                    comboBox_T.DisplayMember = "team_name";
                    comboBox_T.DataSource = dt;
                    comboBox_T.Text = "";
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void comboBox_TA_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (comboBox_TA.Text == comboBox_TH.Text)
                {
                    MessageBox.Show("Cannot Pick the Same team");
                }
                else
                {
                    dt = new DataTable();
                    query = $"SELECT team_name, team_id FROM team WHERE team_id = '{comboBox_TH.SelectedValue}' or team_id = '{comboBox_TA.SelectedValue}'";
                    sqlcommand = new MySqlCommand(query, sqlconnect);
                    sqldataadapter = new MySqlDataAdapter(sqlcommand);
                    sqldataadapter.Fill(dt);

                    comboBox_T.ValueMember = "team_id";
                    comboBox_T.DisplayMember = "team_name";
                    comboBox_T.DataSource = dt;
                    comboBox_T.Text = "";
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void DTP_MD_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                query = $"SELECT concat(date_format(match_date, '%Y'), date_format(match_date, '%m'), date_format(match_Date, '%d')) FROM `match` ORDER BY 1 desc LIMIT 1";
                sqlcommand = new MySqlCommand(query, sqlconnect);
                sqldataadapter = new MySqlDataAdapter(sqlcommand);
                sqldataadapter.Fill(lastmatch);
                year = DTP_MD.Value.Year.ToString();
                month = DTP_MD.Value.Month.ToString();
                date = DTP_MD.Value.Day.ToString();
                if (Convert.ToInt32(month) < 10)
                {
                    month = "0" + month;
                }
                if (Convert.ToInt32(date) < 10)
                {
                    month = "0" + date;
                }
                select = Convert.ToInt32(year + month + date);
                last = Convert.ToInt32(lastmatch.Rows[0][0]);
                if (select < last)
                {
                    MessageBox.Show("Date Picked Cannot be earlier than the last match");
                }
                else
                {
                    query = $"SELECT match_id FROM `match` WHERE match_id like '{year}%' ORDER BY 1 desc LIMIT 1 ";
                    sqlcommand = new MySqlCommand(query, sqlconnect);
                    sqldataadapter = new MySqlDataAdapter(sqlcommand);
                    sqldataadapter.Fill(matchid);

                    if (matchid.Rows.Count == 0)
                    {
                        textBox_MI.Text = year + "001";
                    }
                    else if (matchid.Rows.Count == 1)
                    {
                        totalmatch = Convert.ToInt32(matchid.Rows[0][0]) + 1;
                        textBox_MI.Text = totalmatch.ToString();
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void textBox_M_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void comboBox_T_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox_T.Text != "")
            {
                dtplayer = new DataTable();
                query = $"SELECT p.player_name, p.player_id from player p, team t where t.team_id = '{comboBox_T.SelectedValue}'";
                sqlcommand = new MySqlCommand(query, sqlconnect);
                sqldataadapter = new MySqlDataAdapter(sqlcommand);
                sqldataadapter.Fill(dtplayer);
                comboBox_P.ValueMember = "player_id";
                comboBox_P.DisplayMember = "player_name";
                comboBox_P.DataSource = dtplayer;
                comboBox_P.Text = "";
            }
        }
    }
}
